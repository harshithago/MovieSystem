# Project Title
# SpringMVC-Hibernate-MySQL
Sales and Product Spring MVC +Hibernate+MySql project

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

## HOW TO RUN
# step1: create database name 'assignment'.

# step2: clone the project into local system.
# step3: import code into eclipse.
# step4: Run on server.

# NOTE: tables are creates automatically no need to create tables

