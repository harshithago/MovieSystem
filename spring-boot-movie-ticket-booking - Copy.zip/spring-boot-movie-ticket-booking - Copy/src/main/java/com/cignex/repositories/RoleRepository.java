package com.cignex.repositories;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cignex.entities.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {


}
