-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2022 at 02:43 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movieticketbooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie_master`
--

CREATE TABLE `movie_master` (
  `id` int(11) NOT NULL,
  `cast` varchar(255) DEFAULT NULL,
  `duration_time` varchar(255) DEFAULT NULL,
  `movie_path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie_master`
--

INSERT INTO `movie_master` (`id`, `cast`, `duration_time`, `movie_path`, `name`, `rate`) VALUES
(3, 'test', '2:26:30', 'C:\\Users\\Rishabh\\Desktop\\Movie Ticket SpringBoot\\spring-boot-movie-ticket-booking-master\\src\\main\\webapp\\WEB-INF\\view\\upload\\urinewMovie.jpg', 'test', 3),
(4, 'test', '2:26:30', 'C:\\Users\\Rishabh\\Desktop\\Movie Ticket SpringBoot\\spring-boot-movie-ticket-booking-master\\src\\main\\webapp\\WEB-INF\\view\\upload\\urinewMovie.jpg', 'No movie', 3),
(5, 'Actor', '2:26:30', 'C:\\Users\\Rishabh\\Desktop\\Movie Ticket SpringBoot\\spring-boot-movie-ticket-booking-master\\src\\main\\webapp\\WEB-INF\\view\\upload\\urinewMovie.jpg', 'URI', 4);

-- --------------------------------------------------------

--
-- Table structure for table `movie_show`
--

CREATE TABLE `movie_show` (
  `id` int(11) NOT NULL,
  `booked_seats` tinyblob DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `gold_price` int(11) NOT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `platinium_price` int(11) NOT NULL,
  `silver_price` int(11) NOT NULL,
  `time` time DEFAULT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `screen_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie_show`
--

INSERT INTO `movie_show` (`id`, `booked_seats`, `show_date`, `gold_price`, `payment_type`, `platinium_price`, `silver_price`, `time`, `movie_id`, `screen_id`) VALUES
(1, NULL, '2022-10-30', 2, NULL, 2, 2, '07:18:00', 5, 1),
(2, NULL, '2022-10-30', 3, NULL, 3, 3, '07:19:00', 5, 1),
(3, NULL, '2022-10-30', 3, NULL, 3, 4, '19:22:00', 5, 1),
(4, NULL, '2022-10-30', 3, NULL, 3, 3, '08:19:00', 5, 1),
(5, NULL, '0000-00-00', 2, NULL, 3, 2, '07:23:00', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role`) VALUES
(1, 'ADMIN'),
(2, 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_role_id` int(11) NOT NULL,
  `user_user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`role_role_id`, `user_user_id`) VALUES
(1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `screen_master`
--

CREATE TABLE `screen_master` (
  `id` int(11) NOT NULL,
  `gold_seats` tinyblob DEFAULT NULL,
  `platinium_seats` tinyblob DEFAULT NULL,
  `screen_name` varchar(255) DEFAULT NULL,
  `silver_seats` tinyblob DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `screen_master`
--

INSERT INTO `screen_master` (`id`, `gold_seats`, `platinium_seats`, `screen_name`, `silver_seats`) VALUES
(1, 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b4702000078700000001e740002673174000267327400026733740002673474000267357400026736740002673774000267387400026739740003673130740003673131740003673132740003673133740003673134740003673135740003673136740003673137740003673138740003673139740003673230740003673231740003673232740003673233740003673234740003673235740003673236740003673237740003673238740003673239740003673330, 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b470200007870000000047400027031740002703274000270337400027034, 'Screen A', 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b4702000078700000000574000273317400027332740002733374000273347400027335),
(2, 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b4702000078700000000a740002673174000267327400026733740002673474000267357400026736740002673774000267387400026739740003673130, 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b4702000078700000000a740002703174000270327400027033740002703474000270357400027036740002703774000270387400027039740003703130, 'Screen B', 0xaced0005757200135b4c6a6176612e6c616e672e537472696e673badd256e7e91d7b4702000078700000000a740002733174000273327400027333740002733474000273357400027336740002733774000273387400027339740003733130);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `active` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `active`, `email`, `last_name`, `name`, `password`, `token`) VALUES
(1, 0, 'admin@gmail.com', 'saini', 'rishabh', '$2a$10$gGcBpo9ot4.0kaYB8xtW9OVnWR5J.bC75qSErzmpjUrHI0SVHLSg.', 'cpacegjscscnkdf'),
(2, 0, 'test@gmail.com', 'test', 'rishabh', '$2a$10$62v2eyzshsATq0mlqhUOYuupERwp5x44MQSzeha6giazmWVPh1Ddu', 'bqcbmltxxnnbnsm'),
(3, 0, 'test@gmail.com', 'test', 'test', '$2a$10$enXDvEszfJADpq9KGPkF3u3fj7qnPgc/LMGRoiwzeDUWUFkPGPqCO', 'igjgockypfoxgfg'),
(4, 0, 'admin@gmail.com', 'admin', 'admin', '$2a$10$YerpStD9FFl2hNiMsedSzuG5wiGVeeN5eeLu3Alal99s7tSlRkXCm', 'wzmlgotnfgnfinc'),
(5, 0, 'reddy@g.com', 'reddy', 'reddy', '$2a$10$.DAC4Zdl459ehs2PQaLk8O1a/MpggLa7F42Hy9Xph8BP2zZJBxf3a', 'bviywtdnaixqzcb'),
(6, 0, 'reddy1@g.com', 'reddy1', 'reddy1', '$2a$10$fG50IS0po0Weyv4MyvvIgu9lUbzJoQiyptr0Jn1YWfXr1tG/hib3S', 'eoblkmfgdmawlhu');

-- --------------------------------------------------------

--
-- Table structure for table `user_booked`
--

CREATE TABLE `user_booked` (
  `id` int(11) NOT NULL,
  `booked_seats` tinyblob DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `total` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `screen_id` int(11) DEFAULT NULL,
  `show_id` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_user_id` int(11) NOT NULL,
  `roles_role_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_user_id`, `roles_role_id`) VALUES
(1, 2),
(4, 1),
(5, 2),
(6, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movie_master`
--
ALTER TABLE `movie_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie_show`
--
ALTER TABLE `movie_show`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKfqm19p6utvevkkh90bedt5jwd` (`movie_id`),
  ADD KEY `FKngiseowavia9mine3t10lhj3h` (`screen_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`role_role_id`,`user_user_id`),
  ADD KEY `FKylov3x0si8kxwmihrolu1jev` (`user_user_id`);

--
-- Indexes for table `screen_master`
--
ALTER TABLE `screen_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_booked`
--
ALTER TABLE `user_booked`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK8lwa5scbvt6ws0eyj59fa79ia` (`movie_id`),
  ADD KEY `FK31g0hoes43i95nb1ds24sdd1o` (`screen_id`),
  ADD KEY `FK6scdiq9qelxi83r8qkypfr468` (`show_id`),
  ADD KEY `FKmlr3betulpajobv79jw148srl` (`uid`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_user_id`,`roles_role_id`),
  ADD KEY `FKhxmmg8j4h4qpwbvf39cnujlkf` (`roles_role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movie_master`
--
ALTER TABLE `movie_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `movie_show`
--
ALTER TABLE `movie_show`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `screen_master`
--
ALTER TABLE `screen_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_booked`
--
ALTER TABLE `user_booked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
